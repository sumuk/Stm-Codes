/*
 * dxl_hal.c
 *
 *  Created on: Jun 29, 2016
 *      Author: aman
 */
#include "dxl_hal.h"
#include <stdlib.h>
#include "stm32f3xx_hal.h"
#include "FreeRTOS.h"
#include "task.h"
#include "usart.h"
#define UART_CR1_FIELDS  ((uint32_t)(USART_CR1_M | USART_CR1_PCE | USART_CR1_PS | \
                                     USART_CR1_TE | USART_CR1_RE | USART_CR1_OVER8))
long	glStartTime	= 0;
float	gfRcvWaitTime	= 0.0f;
float	gfByteTransTime	= 0.208f;
int numberofrx;
extern long timems;
extern UART_HandleTypeDef huart3;
extern int uart_count_rx(UART_HandleTypeDef *huart);
extern int uart_count_tx(UART_HandleTypeDef *huart);
int dxl_hal_tx( unsigned char *pPacket, int numPacket )
{
	int num=0,x;
	 uint32_t tmpreg                     = 0x00000000;
				 		 huart3.Init.Mode = UART_MODE_TX;
				 		 tmpreg = (uint32_t)huart3.Init.WordLength | huart3.Init.Parity | huart3.Init.Mode | huart3.Init.OverSampling ;
				 		 MODIFY_REG(huart3.Instance->CR1, UART_CR1_FIELDS, tmpreg);
	while((uart_count_tx(&huart3)<255) && numPacket>=0)
	{
		num++;
		numPacket--;
		 tx_char(&huart3,pPacket++);
	}
	//HAL_GPIO_WritePin(GPIOB, LD_L_Pin, GPIO_PIN_SET);
	x=ceil(.2*num);
	vTaskDelay(x);

        return --num;
}
int dxl_hal_rx( unsigned char *pPacket, int numPacket )
{

	int number=1;
	//memset(pPacket, 0, numPacket);
	if(uart_count_rx(&huart3)&& numPacket>0)
	{
	while(uart_count_rx(&huart3))
	{
	rx_char(&huart3,pPacket++);
	number++;
	}
	}
	numberofrx=number;
	return --number;
}
void dxl_hal_clear(void)
{
	  memset(huart3.Ring_buffer_tx,0,sizeof(huart3.Ring_buffer_tx));
	  memset(huart3.Ring_buffer_rx,0,sizeof(huart3.Ring_buffer_rx));
	  huart3.Ring_head_tx=0;
	  huart3.Ring_head_rx=0;
	  huart3.Ring_tail_rx=0;
	  huart3.Ring_tail_tx=0;

}
void dxl_hal_set_timeout( int NumRcvByte )
{
	glStartTime = timems;
	gfRcvWaitTime = (float)(gfByteTransTime*(float)NumRcvByte + 5.0f);
}

int dxl_hal_timeout(void)
{
	long time;

	time = timems - glStartTime;

	if(time > gfRcvWaitTime)
		return 1;
	else if(time < 0)
		glStartTime = timems;

	return 0;
}

