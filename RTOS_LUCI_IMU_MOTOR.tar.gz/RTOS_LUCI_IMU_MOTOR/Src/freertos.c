/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"

/* USER CODE BEGIN Includes */     
#include "gpio.h"
#include "usart.h"
#include <stdlib.h>
#include "dynamixel.h"
/* USER CODE END Includes */

/* Variables -----------------------------------------------------------------*/
osThreadId defaultTaskHandle;
osThreadId LUCIReadHandle;
osThreadId PacketreadHandle;
osThreadId IMUHandle;
osThreadId DynamixelHandle;

/* USER CODE BEGIN Variables */
long timems;
extern void     HAL_IncTick(void);
#define UART_CR1_FIELDS  ((uint32_t)(USART_CR1_M | USART_CR1_PCE | USART_CR1_PS | \
                                     USART_CR1_TE | USART_CR1_RE | USART_CR1_OVER8))
#define P_GOAL_POSITION_L	30
#define P_GOAL_POSITION_H	31
#define P_PRESENT_POSITION_L	36
#define P_PRESENT_POSITION_H	37
#define P_MOVING		46
#define DEFAULT_ID		1
int state=0;
    uint16_t len,num,command;
    uint8_t comh,coml,crch,crcl,coms,dlh,dll,gors;
    struct packet
    {
    	struct packet *into;
    	uint8_t type;
    	uint8_t cstatus;
    	uint16_t command;
    	uint16_t dlen;
    	char *data;
    };
    struct pdata
    {
    	int count;
    	struct packet *pac_head;
    	struct packet *pac_tail;

    };
    struct pdata packet_info;
    int GoalPos[2] = {0, 1023};
    	  	int index = 0;
    	  	int deviceIndex = 0;
    	  	int Moving, PresentPos;
    	  	int CommStatus;
/* USER CODE END Variables */

/* Function prototypes -------------------------------------------------------*/
void StartDefaultTask(void const * argument);
void LUCIReadHandler(void const * argument);
void PacketHandler(void const * argument);
void IMU_read(void const * argument);
void DynamixelHandler(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* USER CODE BEGIN FunctionPrototypes */
HAL_StatusTypeDef tx_char(UART_HandleTypeDef*,char*);//put the byte into tx ring buffer
HAL_StatusTypeDef rx_char(UART_HandleTypeDef*,char*);//get byte from rx ring buffer
HAL_StatusTypeDef UART_T_IT(UART_HandleTypeDef *huart);//interrupt handler for tx
HAL_StatusTypeDef UART_R_IT(UART_HandleTypeDef *huart);//interrupt handler for rx
int uart_count_rx(UART_HandleTypeDef *huart);//return the no of byte in tx ring buffer
int uart_count_tx(UART_HandleTypeDef *huart);//return the no of byte in rx ring buffer
/* USER CODE END FunctionPrototypes */

/* Hook prototypes */

/* Init FreeRTOS */

void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
       
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, 0, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of LUCIRead */
  osThreadDef(LUCIRead, LUCIReadHandler, 1, 0, 128);
  LUCIReadHandle = osThreadCreate(osThread(LUCIRead), NULL);

  /* definition and creation of Packetread */
  osThreadDef(Packetread, PacketHandler, 1, 0, 128);
  PacketreadHandle = osThreadCreate(osThread(Packetread), NULL);

  /* definition and creation of IMU */
  osThreadDef(IMU, IMU_read, 1, 0, 128);
  IMUHandle = osThreadCreate(osThread(IMU), NULL);

  /* definition and creation of Dynamixel */
  osThreadDef(Dynamixel, DynamixelHandler, 1, 0, 128);
  DynamixelHandle = osThreadCreate(osThread(Dynamixel), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
}

/* StartDefaultTask function */
void StartDefaultTask(void const * argument)
{

  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* LUCIReadHandler function */
void LUCIReadHandler(void const * argument)
{
  /* USER CODE BEGIN LUCIReadHandler */
	char a[2];
  /* Infinite loop */
  for(;;)
  {
	  if(uart_count_rx(&huart2))//check if ring buffer has data
	  	  {

	  		  if( rx_char(&huart2,a) == HAL_OK)//extract data from ring buffer
	  		  {
	  			 static struct packet *pack;//variable used for creating structure
	  			 static char *p;//pointer used for pointing data in structure
	            switch(state)//state machine
	            {
	            case 0:
	           	 state=(a[0]==0xaa)?1:0;//check for 0xaa for start of packet
	            break;
	            case 1:
	           	 state=(a[0]==0xaa)?2:0;//check for 0xaa for second byte of packet

	            break;
	            case 2:
	           	 gors=a[0];//byte represents set or get response
	           	 state=3;
	           break;
	            case 3:
	           	 comh=a[0];//command  high byte(LUCI is in big endian format)
	           	 state=4;
	           	 break;
	            case 4:
	           	 coml=a[0];//command low byte
	           	 state=5;
	           	 command=(comh<<8)+coml;//command is of 16bits
	           	 break;
	            case 5:
	           	 coms=a[0];//command status is of 8 bits
	           	 state=6;
	           	 break;
	            case 6:
	           	 crch=a[0];//crc high byte
	           	 state=7;
	           	break;
	            case 7:
	           	 crcl=a[0];//crc low byte
	           	 state=8;
	           	 break;
	            case 8:
	           	 dlh=a[0];//data length high byte
	           	 state=9;
	           	 break;
	            case 9:
	           	 dll=a[0];//data length low byte
	           	 state=10;
	           	 num=(dlh<<8)+dll;//data length 16 bits
	           	 len=0;
	           	 pack=(struct packet *)malloc(sizeof(struct packet));//creating packet structure for adding into queue
	           	 memset(pack,0,sizeof(0));//set the memory with zero
	           	                 	    	pack->command=command;//set the command
	           	                 	    	pack->dlen=num;//set the data length
	           	                 	    	pack->type=gors;//set the get or set response
	           	                 	    	pack->cstatus=coms;//set command status

	           	                 	    	if(num>0)//check if data is present
	           	                 	    	{
	           	                 	    		p=(char *)malloc(num);//allocate memory for data
	           	                 	    		pack->data=p;//point the pointer for data
	           	                 	    		if(!packet_info.count)//check if count is zero as tail is null pointer
	           	                 	    		   packet_info.pac_tail=pack;//set the tail pointer for new structure
	           	                 	    	}
	           	                 	    	else
	           	                 	    	{
	           	                 	    		pack->data=NULL;//if data is zero the assigned zero
	           	                 	    		state=0;//make state zero packet is genrated should be added to queue
	           	                 	    		len=0;//reset the variable
	           	                 	            num=0;//reset the variable
	           	                 	           if(!packet_info.count)//check if count is zero as tail is null pointer
	           	                 	               packet_info.pac_tail=pack;//set the tail pointer for new structure
	           	                 	    		if(packet_info.count)//check the count
	           	                 	    		{
	           	                 	    		 packet_info.pac_head->into=pack;//previous structure point to new structure
	           	                 	    	     }
	           	                 	    	     packet_info.pac_head=pack;//make head point to new structure
	           	                 	    		 packet_info.count++;//increase the count
	           	                 	    	}

	           	 break;
	            case 10:
	           	     if(num>0)//check if data length greater than zero to store data
	           	     {
	           		   *(p++)=a[0];//put the data into memory
	           		   len++;//increase the length
	           	     }
	           		 if(len==num)//check if all data is received
	           			 {
	           			 state=0;//state machine reset for new packet
	           			 len=0;//reset the variable
	           			 num=0;//reset the variable
	           			if(packet_info.count)//check the queue
	           			{
	           				packet_info.pac_head->into=pack;//point the old structure to new structure
	           			}
	           			 packet_info.pac_head=pack;//point the head to new structure
	           			 packet_info.count++;//increase the count in the queue
	           			 }
	           		 break;
	              }
	  		  }
	  	  }
    osDelay(1);
  }
  /* USER CODE END LUCIReadHandler */
}

/* PacketHandler function */
void PacketHandler(void const * argument)
{
  /* USER CODE BEGIN PacketHandler */
  /* Infinite loop */
  for(;;)
  {
	  if(packet_info.count)//check if queue has packet
	 	  	  	  	  {

	 	  	  	         int volume=0;
	 	  	  	  		  switch(packet_info.pac_tail->command)//recode the command type of tail
	 	  	  	  		  {

	 	  	  	  		  case 64://volume command used in luci

	 	  	  	  			  			for(int i=0;i<packet_info.pac_tail->dlen;i++)
	 	  	  	  			  						volume=volume*10+*(packet_info.pac_tail->data++)-0x30;
	 	  	  	  			  					if(volume==100)
	 	  	  	  			  					{
	 	  	  	  			  					 HAL_GPIO_WritePin(GPIOB, LD_U_Pin|LD_D_Pin, GPIO_PIN_SET);
	 	  	  	  			  				  dxl_write_word( DEFAULT_ID, P_GOAL_POSITION_L,512);
	 	  	  	  			  			     //  volume=0;
	 	  	  	  			  			       dxl_write_byte( DEFAULT_ID,25,0x01);

	 	  	  	  			  					}
	 	  	  	  			  					 else
	 	  	  	  			  					 {
	 	  	  	  			  						HAL_GPIO_WritePin(GPIOB, LD_U_Pin|LD_D_Pin, GPIO_PIN_RESET);
	 	  	  	  			  				dxl_write_word( DEFAULT_ID, P_GOAL_POSITION_L,0);
	 	  	  	  			  	           //	volume=0;
	 	  	  	  			  		       dxl_write_byte( DEFAULT_ID,25,0x00);

	 	  	  	  			  					 }
	 	  	  	  			  					//HAL_Delay(10);
	 	  	  	  			  			volume=0;
	 	  	  	  			  	 HAL_GPIO_WritePin(GPIOB, LD_L_Pin, GPIO_PIN_RESET);
	 	  	  	  			  	    int PresentPos = dxl_read_word( DEFAULT_ID,30 );
	 	  	  	  			  HAL_GPIO_WritePin(GPIOB, LD_L_Pin, GPIO_PIN_SET);
	 	  	  	  			  		int CommStatus = dxl_get_result();
	 	  	  	  			 // HAL_GPIO_WritePin(GPIOB, LD_L_Pin, GPIO_PIN_SET);
	 	  	  	  			  				if( CommStatus == COMM_RXSUCCESS )
	 	  	  	  			  				{

	 	  	  	  			  			if(PresentPos==512)
	 	  	  	  			  		    HAL_GPIO_WritePin(GPIOB, LD_R_Pin, GPIO_PIN_SET);
	 	  	  	  			  			 else
	 	  	  	  			  			HAL_GPIO_WritePin(GPIOB, LD_R_Pin, GPIO_PIN_RESET);
	 	  	  	  			  				}
	 	  	  	  			  				else

	 	  	  	  			  				{
	 	  	  	  			  			 HAL_GPIO_WritePin(GPIOB, LD_R_Pin, GPIO_PIN_RESET);

	 	  	  	  			  				}



	 	  	  	  			  break;
	 	  	  	  		  }
	 	  	  	  		  packet_info.count--;//reduce the count of packet
	 	  	  	  		  struct packet *temp=packet_info.pac_tail->into;//store the pointer in temp variable
	 	  	  	  		  free(packet_info.pac_tail);//free the memory of the packet
	 	  	  	  		  packet_info.pac_tail=temp;//point he tail to new top of queue
	 	  	  	  	  }
    osDelay(1);
  }
  /* USER CODE END PacketHandler */
}

/* IMU_read function */
void IMU_read(void const * argument)
{
  /* USER CODE BEGIN IMU_read */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END IMU_read */
}

/* DynamixelHandler function */
void DynamixelHandler(void const * argument)
{
  /* USER CODE BEGIN DynamixelHandler */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END DynamixelHandler */
}

/* USER CODE BEGIN Application */
void HAL_IncTick(void)
{
	timems++;
}
int uart_count_rx(UART_HandleTypeDef *huart)
{
	return (unsigned int)(buffer_size + huart->Ring_head_rx - huart->Ring_tail_rx) % buffer_size;
}
int uart_count_tx(UART_HandleTypeDef *huart)
{
	return (unsigned int)(buffer_size + huart->Ring_head_tx - huart->Ring_tail_tx) % buffer_size;
}
HAL_StatusTypeDef rx_char(UART_HandleTypeDef *huart,char *a)
{
	if( uart_count_rx(huart)>0)
		__HAL_UART_ENABLE_IT(huart, UART_IT_RXNE);
	if (huart->Ring_head_rx == huart->Ring_tail_rx) {


			if(huart->State == HAL_UART_STATE_BUSY_TX)
			      {
			        huart->State = HAL_UART_STATE_BUSY_TX_RX;
			      }
			      else
			      {
			        /* Disable the UART Parity Error Interrupt */
			        __HAL_UART_ENABLE_IT(huart, UART_IT_PE);

			        /* Disable the UART Error Interrupt: (Frame error, noise error, overrun error) */
			        __HAL_UART_ENABLE_IT(huart, UART_IT_ERR);

			        huart->State = HAL_UART_STATE_BUSY_RX;
			      }
			return HAL_ERROR;
			} else {
			*a = huart->Ring_buffer_rx[huart->Ring_tail_rx];
			 huart->Ring_tail_rx= (uint8_t)(huart->Ring_tail_rx+ 1) % buffer_size;
			return HAL_OK;
}
}
HAL_StatusTypeDef tx_char(UART_HandleTypeDef *huart,char *a)
{
	  /* Process Locked */
	__HAL_LOCK(huart);
		int i = (huart->Ring_head_tx + 1) % buffer_size;
		 if(i == huart->Ring_tail_tx)
		 {
			  /* Process Unlocked */
			 __HAL_UNLOCK(huart);
			 return HAL_ERROR;
		 }
		 huart->Ring_buffer_tx[huart->Ring_head_tx]=*a;
		 huart->Ring_head_tx = i;
		 if(huart->State == HAL_UART_STATE_BUSY_RX)
		     {
		       huart->State = HAL_UART_STATE_BUSY_TX_RX;
		     }
		     else
		     {
		       huart->State = HAL_UART_STATE_BUSY_TX;
		     }
		  /* Process Unlocked */
		 __HAL_UNLOCK(huart);
		 /* Enable the UART Transmit Data Register Empty Interrupt */
		 __HAL_UART_ENABLE_IT(huart, UART_IT_TXE);
		/* if(huart->Instance==USART3)
		 {
			 uint32_t tmpreg                     = 0x00000000;
			 		 huart3.Init.Mode = UART_MODE_TX;
			 		 tmpreg = (uint32_t)huart->Init.WordLength | huart->Init.Parity | huart->Init.Mode | huart->Init.OverSampling ;
			 		 MODIFY_REG(huart->Instance->CR1, UART_CR1_FIELDS, tmpreg);
			 		// HAL_Delay(1);
		 }*/
	return HAL_OK;
}
HAL_StatusTypeDef UART_T_IT(UART_HandleTypeDef *huart)
{

  if ((huart->State == HAL_UART_STATE_BUSY_TX) || (huart->State == HAL_UART_STATE_BUSY_TX_RX))
  {

    if(huart->Ring_head_tx == huart->Ring_tail_tx)
    {
      /* Disable the UART Transmit Data Register Empty Interrupt */
      __HAL_UART_DISABLE_IT(huart, UART_IT_TXE);

      /* Enable the UART Transmit Complete Interrupt */
      __HAL_UART_ENABLE_IT(huart, UART_IT_TC);
      //HAL_UART_TxCpltCallback(&huart);
      return HAL_OK;
    }
    else
    {

        huart->Instance->TDR = (uint8_t)(huart->Ring_buffer_tx[huart->Ring_tail_tx ] & (uint8_t)0xFF);

        huart->Ring_tail_tx = (huart->Ring_tail_tx + 1) % buffer_size;


      return HAL_OK;
    }
  }
  else
  {
    return HAL_BUSY;
  }
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Ring_head_tx == huart->Ring_tail_tx)
	    {
	      /* Disable the UART Transmit Data Register Empty Interrupt */
	      __HAL_UART_DISABLE_IT(huart, UART_IT_TXE);

	      /* Enable the UART Transmit Complete Interrupt */
	      __HAL_UART_DISABLE_IT(huart, UART_IT_TC);
	      if(huart->Instance==USART3)
	      		 {
	      			 uint32_t tmpreg                     = 0x00000000;
	      			 		 huart3.Init.Mode = UART_MODE_RX;
	      			 		 tmpreg = (uint32_t)huart->Init.WordLength | huart->Init.Parity | huart->Init.Mode | huart->Init.OverSampling ;
	      			 		 MODIFY_REG(huart->Instance->CR1, UART_CR1_FIELDS, tmpreg);
	      		 }

	    }
	else
		__HAL_UART_ENABLE_IT(huart, UART_IT_TXE);
}
HAL_StatusTypeDef UART_R_IT(UART_HandleTypeDef *huart)
{

	  uint16_t uhMask = huart->Mask;
	  //HAL_GPIO_TogglePin(GPIOC, LD4_Pin);
	  //if((huart->State == HAL_UART_STATE_BUSY_RX) || (huart->State == HAL_UART_STATE_BUSY_TX_RX))
	  //{
		  int i = (unsigned int)(huart->Ring_head_rx + 1) % buffer_size;


	      		if (i != huart->Ring_tail_rx)
	      		{
	      			huart->Ring_buffer_rx[huart->Ring_head_rx] = (uint8_t)(huart->Instance->RDR & (uint8_t)uhMask);
	      			huart->Ring_head_rx = i;
	      		}

	    if(huart->Ring_head_rx == huart->Ring_tail_tx)
	    {
	      __HAL_UART_DISABLE_IT(huart, UART_IT_RXNE);

	      /* Check if a transmit Process is ongoing or not */
	      if(huart->State == HAL_UART_STATE_BUSY_TX_RX)
	      {
	        huart->State = HAL_UART_STATE_BUSY_TX;
	      }
	      else
	      {
	        /* Disable the UART Parity Error Interrupt */
	        __HAL_UART_DISABLE_IT(huart, UART_IT_PE);

	        /* Disable the UART Error Interrupt: (Frame error, noise error, overrun error) */
	        __HAL_UART_DISABLE_IT(huart, UART_IT_ERR);

	        huart->State = HAL_UART_STATE_READY;
	      }

	      //HAL_UART_RxCpltCallback(huart);

	      return HAL_OK;
	    }

	    return HAL_OK;
	  //}
	  //else
	  //{
	    //return HAL_BUSY;
	  //}
}
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
