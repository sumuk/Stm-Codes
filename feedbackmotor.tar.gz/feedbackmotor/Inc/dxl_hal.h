/*
 * dxl_hal.h
 *
 *  Created on: Jun 29, 2016
 *      Author: aman
 */

#ifndef INC_DXL_HAL_H_
#define INC_DXL_HAL_H_

int dxl_hal_tx( unsigned char *pPacket, int numPacket );
int dxl_hal_rx( unsigned char *pPacket, int numPacket );
void dxl_hal_clear(void);
int dxl_hal_timeout(void);
void dxl_hal_set_timeout( int NumRcvByte );
#endif /* INC_DXL_HAL_H_ */
