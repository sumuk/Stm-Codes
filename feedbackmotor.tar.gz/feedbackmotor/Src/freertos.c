/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"

/* USER CODE BEGIN Includes */     
#include "gpio.h"
#include "usart.h"
#include <stdlib.h>
#include "dynamixel.h"
#include "core_cm4.h"
#include <math.h>
//#include <math.h>

/* USER CODE END Includes */

/* Variables -----------------------------------------------------------------*/
osThreadId defaultTaskHandle;
osThreadId Com_PortHandle;
osThreadId Motor_FeedbackHandle;

/* USER CODE BEGIN Variables */
long timems;
extern void     HAL_IncTick(void);
#define UART_CR1_FIELDS  ((uint32_t)(USART_CR1_M | USART_CR1_PCE | USART_CR1_PS | \
                                     USART_CR1_TE | USART_CR1_RE | USART_CR1_OVER8))
#define P_GOAL_POSITION_L	30
#define P_GOAL_POSITION_H	31
#define P_PRESENT_POSITION_L	36
#define P_PRESENT_POSITION_H	37
#define P_MOVING		46
#define DEFAULT_ID		1
#define NUM_ACTUATOR 10
#define converttopos 652.229
int state=0;
    uint16_t len,num,command;
    uint8_t comh,coml,crch,crcl,coms,dlh,dll,gors;
    /*struct packet
    {
    	struct packet *into;
    	uint8_t type;
    	uint8_t cstatus;
    	uint16_t command;
    	uint16_t dlen;
    	char *data;
    };*/
    struct  motordata
    {
    	struct motordata *into;
    	uint8_t motorcount;
    	uint8_t dlen;
    	char *data;
    };
    struct qdata
    {
    	int count;
    	    	struct motordata *pac_head;
    	    	struct motordata *pac_tail;
    };
    /*struct pdata
    {
    	int count;
    	struct packet *pac_head;
    	struct packet *pac_tail;

    };*/
    //struct pdata packet_info;
    struct qdata packet_info;
    double tl[5]={0};
    double tr[5]={0};
    double t1[5]={0};
    double t2[5]={0};
    uint16_t pos[10],vel[10];
    int direction_left[5]={-1,-1,1,-1,1};
	int direction_right[5]={-1,1,-1,1,1};
	//float tx1[60]={15,15,14.671,14.093,13.36,12.48,11.464,10.322,9.0673,7.7131,6.2744,4.767,3.2073,1.6125,0,-1.6125,-3.2073,-4.767,-6.2744,-7.7131,-9.0673,-10.322,-11.464,-12.48,-13.36,-14.093,-14.671,-15,-15,-15,-15,-15,-14.671,-14.093,-13.36,-12.48,-11.464,-10.322,-9.0673,-7.7131,-6.2744,-4.767,-3.2073,-1.6125,0,1.6125,3.2073,4.767,6.2744,7.7131,9.0673,10.322,11.464,12.48,13.36,14.093,14.671,15,15,15};
	//float ty1[60]={1.2475,0.50326,-0.22458,-0.92806,-1.5995,-2.2314,-2.817,-3.3498,-3.824,-4.2344,-4.5765,-4.8466,-5,-5,-5,-5,-5,-4.8466,-4.5765,-4.2344,-3.824,-3.3498,-2.817,-2.2314,-1.5995,-0.92806,-0.22458,0.50326,1.2475,2,2.7525,3.4967,4.2246,4.9281,5.5995,6.2314,6.817,7.3498,7.824,8.2344,8.5765,8.8466,9,9,9,9,9,8.8466,8.5765,8.2344,7.824,7.3498,6.817,6.2314,5.5995,4.9281,4.2246,3.4967,2.7525,2};
	//float tz1[60]={-1.075,-2.1382,-3.178,-4.1829,-5.1421,-6.0449,-6.8814,-7.6426,-8.3201,-8.9063,-9.395,-9.7808,-10,-10,-10,-10,-10,-9.7808,-9.395,-8.9063,-8.3201,-7.6426,-6.8814,-6.0449,-5.1421,-4.1829,-3.178,-2.1382,-1.075,1.8892e-15,3.225,6.4146,9.5339,12.549,15.426,18.135,20.644,22.928,24.96,26.719,28.185,29.342,30,30,30,30,30,29.342,28.185,26.719,24.96,22.928,20.644,18.135,15.426,12.549,9.5339,6.4146,3.225,0};

	//float tx2[60]={-15,-15,-14.671,-14.093,-13.36,-12.48,-11.464,-10.322,-9.0673,-7.7131,-6.2744,-4.767,-3.2073,-1.6125,0,1.6125,3.2073,4.767,6.2744,7.7131,9.0673,10.322,11.464,12.48,13.36,14.093,14.671,15,15,15,15,15,14.671,14.093,13.36,12.48,11.464,10.322,9.0673,7.7131,6.2744,4.767,3.2073,1.6125,0,-1.6125,-3.2073,-4.767,-6.2744,-7.7131,-9.0673,-10.322,-11.464,-12.48,-13.36,-14.093,-14.671,-15,-15,-15};
	//float ty2[60]={-2.7525,-3.4967,-4.2246,-4.9281,-5.5995,-6.2314,-6.817,-7.3498,-7.824,-8.2344,-8.5765,-8.8466,-9,-9,-9,-9,-9,-8.8466,-8.5765,-8.2344,-7.824,-7.3498,-6.817,-6.2314,-5.5995,-4.9281,-4.2246,-3.4967,-2.7525,-2,-1.2475,-0.50326,0.22458,0.92806,1.5995,2.2314,2.817,3.3498,3.824,4.2344,4.5765,4.8466,5,5,5,5,5,4.8466,4.5765,4.2344,3.824,3.3498,2.817,2.2314,1.5995,0.92806,0.22458,-0.50326,-1.2475,-2};
	//float tz2[60]={3.225,6.4146,9.5339,12.549,15.426,18.135,20.644,22.928,24.96,26.719,28.185,29.342,30,30,30,30,30,29.342,28.185,26.719,24.96,22.928,20.644,18.135,15.426,12.549,9.5339,6.4146,3.225,0,-1.075,-2.1382,-3.178,-4.1829,-5.1421,-6.0449,-6.8814,-7.6426,-8.3201,-8.9063,-9.395,-9.7808,-10,-10,-10,-10,-10,-9.7808,-9.395,-8.9063,-8.3201,-7.6426,-6.8814,-6.0449,-5.1421,-4.1829,-3.178,-2.1382,-1.075,0};

	float tx1[40]={15,14.671,13.745,12.48,10.908,9.0673,7.0034,4.767,2.4132,0,-2.4132,-4.767,-7.0034,-9.0673,-10.908,-12.48,-13.745,-14.671,-15,-15,-15,-14.671,-13.745,-12.48,-10.908,-9.0673,-7.0034,-4.767,-2.4132,0,2.4132,4.767,7.0034,9.0673,10.908,12.48,13.745,14.671,15,15};
	float ty1[40]={0.87384,-0.22458,-1.2682,-2.2314,-3.0904,-3.824,-4.4143,-4.8466,-5,-5,-5,-4.8466,-4.4143,-3.824,-3.0904,-2.2314,-1.2682,-0.22458,0.87384,2,3.1262,4.2246,5.2682,6.2314,7.0904,7.824,8.4143,8.8466,9,9,9,8.8466,8.4143,7.824,7.0904,6.2314,5.2682,4.2246,3.1262,2};
	float tz1[40]={-1.6088,-3.178,-4.6689,-6.0449,-7.272,-8.3201,-9.1632,-9.7808,-10,-10,-10,-9.7808,-9.1632,-8.3201,-7.272,-6.0449,-4.6689,-3.178,-1.6088,0,4.8264,9.5339,14.007,18.135,21.816,24.96,27.49,29.342,30,30,30,29.342,27.49,24.96,21.816,18.135,14.007,9.5339,4.8264,0};

	float tx2[40]={-15,-14.671,-13.745,-12.48,-10.908,-9.0673,-7.0034,-4.767,-2.4132,0,2.4132,4.767,7.0034,9.0673,10.908,12.48,13.745,14.671,15,15,15,14.671,13.745,12.48,10.908,9.0673,7.0034,4.767,2.4132,0,-2.4132,-4.767,-7.0034,-9.0673,-10.908,-12.48,-13.745,-14.671,-15,-15};
	float ty2[40]={-3.1262,-4.2246,-5.2682,-6.2314,-7.0904,-7.824,-8.4143,-8.8466,-9,-9,-9,-8.8466,-8.4143,-7.824,-7.0904,-6.2314,-5.2682,-4.2246,-3.1262,-2,-0.87384,0.22458,1.2682,2.2314,3.0904,3.824,4.4143,4.8466,5,5,5,4.8466,4.4143,3.824,3.0904,2.2314,1.2682,0.22458,-0.87384,-2};
	float tz2[40]={4.8264,9.5339,14.007,18.135,21.816,24.96,27.49,29.342,30,30,30,29.342,27.49,24.96,21.816,18.135,14.007,9.5339,4.8264,0,-1.6088,-3.178,-4.6689,-6.0449,-7.272,-8.3201,-9.1632,-9.7808,-10,-10,-10,-9.7808,-9.1632,-8.3201,-7.272,-6.0449,-4.6689,-3.178,-1.6088,0};
/* USER CODE END Variables */

/* Function prototypes -------------------------------------------------------*/
void StartDefaultTask(void const * argument);
void PacketHandler(void const * argument);
void MotorHandler(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* USER CODE BEGIN FunctionPrototypes */
HAL_StatusTypeDef tx_char(UART_HandleTypeDef*,char*);//put the byte into tx ring buffer
HAL_StatusTypeDef rx_char(UART_HandleTypeDef*,char*);//get byte from rx ring buffer
HAL_StatusTypeDef UART_T_IT(UART_HandleTypeDef *huart);//interrupt handler for tx
HAL_StatusTypeDef UART_R_IT(UART_HandleTypeDef *huart);//interrupt handler for rx
int uart_count_rx(UART_HandleTypeDef *huart);//return the no of byte in tx ring buffer
int uart_count_tx(UART_HandleTypeDef *huart);//return the no of byte in rx ring buffer
void syncwrite(uint16_t *pos,uint16_t *vel);
void ik(double *ptr,double x,double y,double z,double phi,double sig,double dip);
void motor(uint16_t *pos,uint16_t *vel,double *tl,double *t2);
void getelement(double *ptr,double *element,int no);
void setelement(double *ptr,double element,int no);
/* USER CODE END FunctionPrototypes */

/* Hook prototypes */

/* Init FreeRTOS */

void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
       
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityIdle, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of Com_Port */
  osThreadDef(Com_Port, PacketHandler, osPriorityLow, 0, 128);
  Com_PortHandle = osThreadCreate(osThread(Com_Port), NULL);

  /* definition and creation of Motor_Feedback */
  osThreadDef(Motor_Feedback, MotorHandler, osPriorityNormal, 0, 128);
  Motor_FeedbackHandle = osThreadCreate(osThread(Motor_Feedback), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
}

/* StartDefaultTask function */
void StartDefaultTask(void const * argument)
{

  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* PacketHandler function */
void PacketHandler(void const * argument)
{
  /* USER CODE BEGIN PacketHandler */
	char a[2];
	int flag=0,i;
  /* Infinite loop */
  for(;;)
  {
	  if(packet_info.count)// && uart_count_tx(&huart2)/(packet_info.pac_tail->dlen+5))//check if ring buffer has data
	  	  {
		  a[0]=255;
		  if( tx_char(&huart2,a) != HAL_OK)
            flag=1;
          if( tx_char(&huart2,a) != HAL_OK)
        	  flag=1;
          a[0]=packet_info.pac_tail->motorcount;
          if( tx_char(&huart2,a) != HAL_OK)
              flag=1;
          a[0]=packet_info.pac_tail->dlen;
          if( tx_char(&huart2,a) != HAL_OK)
              flag=1;
          char *cp=packet_info.pac_tail->data;
          for(i=0;i<packet_info.pac_tail->dlen;i++)
          {
        	  a[0]=*cp++;
        	  if( tx_char(&huart2,a) != HAL_OK)
        	    {
        		  flag=1;
        		  break;
        	    }
          }
          if(!flag)
          {
        	   free(packet_info.pac_tail->data);
		       packet_info.count--;//reduce the count of packet
		 	   struct packet *temp=packet_info.pac_tail->into;//store the pointer in temp variable
	    	   free(packet_info.pac_tail);//free the memory of the packet
		 	   packet_info.pac_tail=temp;//point he tail to new top of queue
               flag=0;
          }


	  	  }
    osDelay(1);
  }
  /* USER CODE END PacketHandler */
}

/* MotorHandler function */
void MotorHandler(void const * argument)
{
  /* USER CODE BEGIN MotorHandler */
	long stamp;
	uint8_t a=0,i;
	static char *p;
  /* Infinite loop */
  for(;;)
  {
	  static struct motordata *pack;
	  stamp=timems;
	 // HAL_GPIO_WritePin(GPIOB, LD_U_Pin|LD_D_Pin, GPIO_PIN_SET);
	  //if(a==0)
	  //{
	    //  dxl_write_byte( DEFAULT_ID,25,0x01);
	  for(i=0;i<40;i++)
	  {
	  stamp=timems;
	  ik(tl,tx1[i],ty1[i],tz1[i],90,1,15);
	  ik(tr,tx2[i],ty2[i],tz2[i],90,1,15);
	  motor(pos,vel,tl,tr);
      syncwrite(pos,vel);
     // vTaskDelay(1);
	  }
	    //   a=1;
	  //}else
	  //{
		//  syncwrite();
		  //dxl_write_byte( DEFAULT_ID,25,0x00);
		  //a=0;
	  //}
	  for(i=0;i<NUM_ACTUATOR;i++)
	  {
	 uint16_t led = dxl_read_word(i+1,36);
	 int CommStatus = dxl_get_result();
	 pack=(struct motordata *)malloc(sizeof(struct motordata ));//creating packet structure for adding into queue
	 memset(pack,0,sizeof(0));
	 pack->motorcount=i+1;
	 pack->dlen=2;
	 p=(char *)malloc(2);//allocate memory for data
	 memset(p,0,sizeof(2));
	 pack->data=p;
	 if( CommStatus == COMM_RXSUCCESS )
	 {
		 *p=(0xff)&led;
		 *(++p)=(0xff)&(led>>8);
	 }

	 else
	 {
		 *p=0x00;
		 *(++p)=0x00;
	 }


	 if(!packet_info.count)//check if count is zero as tail is null pointer
	    packet_info.pac_tail=pack;//set the tail pointer for new structure
	 else
	    packet_info.pac_head->into=pack;//point the old structure to new structure

	 packet_info.pac_head=pack;//point the head to new structure
	 packet_info.count++;//increase the count in the queue
	  }

     vTaskDelay(1);
    //osDelay(1);
  }
  /* USER CODE END MotorHandler */
}

/* USER CODE BEGIN Application */
void HAL_IncTick(void)
{
	timems++;
}
int uart_count_rx(UART_HandleTypeDef *huart)
{
	return (unsigned int)(buffer_size + huart->Ring_head_rx - huart->Ring_tail_rx) % buffer_size;
}
int uart_count_tx(UART_HandleTypeDef *huart)
{
	return (unsigned int)(buffer_size + huart->Ring_head_tx - huart->Ring_tail_tx) % buffer_size;
}
HAL_StatusTypeDef rx_char(UART_HandleTypeDef *huart,char *a)
{
	if( uart_count_rx(huart)>0)
		__HAL_UART_ENABLE_IT(huart, UART_IT_RXNE);
	if (huart->Ring_head_rx == huart->Ring_tail_rx) {


			if(huart->State == HAL_UART_STATE_BUSY_TX)
			      {
			        huart->State = HAL_UART_STATE_BUSY_TX_RX;
			      }
			      else
			      {
			        /* Disable the UART Parity Error Interrupt */
			        __HAL_UART_ENABLE_IT(huart, UART_IT_PE);

			        /* Disable the UART Error Interrupt: (Frame error, noise error, overrun error) */
			        __HAL_UART_ENABLE_IT(huart, UART_IT_ERR);

			        huart->State = HAL_UART_STATE_BUSY_RX;
			      }
			return HAL_ERROR;
			} else {
			*a = huart->Ring_buffer_rx[huart->Ring_tail_rx];
			 huart->Ring_tail_rx= (uint8_t)(huart->Ring_tail_rx+ 1) % buffer_size;
			return HAL_OK;
}
}
HAL_StatusTypeDef tx_char(UART_HandleTypeDef *huart,char *a)
{
	  /* Process Locked */
	__HAL_LOCK(huart);
		int i = (huart->Ring_head_tx + 1) % buffer_size;
		 if(i == huart->Ring_tail_tx)
		 {
			  /* Process Unlocked */
			 __HAL_UNLOCK(huart);
			 return HAL_ERROR;
		 }
		 huart->Ring_buffer_tx[huart->Ring_head_tx]=*a;
		 huart->Ring_head_tx = i;
		 if(huart->State == HAL_UART_STATE_BUSY_RX)
		     {
		       huart->State = HAL_UART_STATE_BUSY_TX_RX;
		     }
		     else
		     {
		       huart->State = HAL_UART_STATE_BUSY_TX;
		     }
		  /* Process Unlocked */
		 __HAL_UNLOCK(huart);
		 /* Enable the UART Transmit Data Register Empty Interrupt */
		 __HAL_UART_ENABLE_IT(huart, UART_IT_TXE);
		/* if(huart->Instance==USART3)
		 {
			 uint32_t tmpreg                     = 0x00000000;
			 		 huart3.Init.Mode = UART_MODE_TX;
			 		 tmpreg = (uint32_t)huart->Init.WordLength | huart->Init.Parity | huart->Init.Mode | huart->Init.OverSampling ;
			 		 MODIFY_REG(huart->Instance->CR1, UART_CR1_FIELDS, tmpreg);
			 		// HAL_Delay(1);
		 }*/
	return HAL_OK;
}
HAL_StatusTypeDef UART_T_IT(UART_HandleTypeDef *huart)
{

  if ((huart->State == HAL_UART_STATE_BUSY_TX) || (huart->State == HAL_UART_STATE_BUSY_TX_RX))
  {

    if(huart->Ring_head_tx == huart->Ring_tail_tx)
    {
      /* Disable the UART Transmit Data Register Empty Interrupt */
      __HAL_UART_DISABLE_IT(huart, UART_IT_TXE);

      /* Enable the UART Transmit Complete Interrupt */
      __HAL_UART_ENABLE_IT(huart, UART_IT_TC);
      //HAL_UART_TxCpltCallback(&huart);
      return HAL_OK;
    }
    else
    {

        huart->Instance->TDR = (uint8_t)(huart->Ring_buffer_tx[huart->Ring_tail_tx ] & (uint8_t)0xFF);

        huart->Ring_tail_tx = (huart->Ring_tail_tx + 1) % buffer_size;


      return HAL_OK;
    }
  }
  else
  {
    return HAL_BUSY;
  }
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Ring_head_tx == huart->Ring_tail_tx)
	    {
	      /* Disable the UART Transmit Data Register Empty Interrupt */
	      __HAL_UART_DISABLE_IT(huart, UART_IT_TXE);

	      /* Enable the UART Transmit Complete Interrupt */
	      __HAL_UART_DISABLE_IT(huart, UART_IT_TC);
	      if(huart->Instance==USART3)
	      		 {
	      			 uint32_t tmpreg                     = 0x00000000;
	      			 		 huart3.Init.Mode = UART_MODE_RX;
	      			 		 tmpreg = (uint32_t)huart->Init.WordLength | huart->Init.Parity | huart->Init.Mode | huart->Init.OverSampling ;
	      			 		 MODIFY_REG(huart->Instance->CR1, UART_CR1_FIELDS, tmpreg);
	      		 }

	    }
	else
		__HAL_UART_ENABLE_IT(huart, UART_IT_TXE);
}
HAL_StatusTypeDef UART_R_IT(UART_HandleTypeDef *huart)
{

	  uint16_t uhMask = huart->Mask;
	  //HAL_GPIO_TogglePin(GPIOC, LD4_Pin);
	  //if((huart->State == HAL_UART_STATE_BUSY_RX) || (huart->State == HAL_UART_STATE_BUSY_TX_RX))
	  //{
		  int i = (unsigned int)(huart->Ring_head_rx + 1) % buffer_size;


	      		if (i != huart->Ring_tail_rx)
	      		{
	      			huart->Ring_buffer_rx[huart->Ring_head_rx] = (uint8_t)(huart->Instance->RDR & (uint8_t)uhMask);
	      			huart->Ring_head_rx = i;
	      		}

	    if(huart->Ring_head_rx == huart->Ring_tail_tx)
	    {
	      __HAL_UART_DISABLE_IT(huart, UART_IT_RXNE);

	      /* Check if a transmit Process is ongoing or not */
	      if(huart->State == HAL_UART_STATE_BUSY_TX_RX)
	      {
	        huart->State = HAL_UART_STATE_BUSY_TX;
	      }
	      else
	      {
	        /* Disable the UART Parity Error Interrupt */
	        __HAL_UART_DISABLE_IT(huart, UART_IT_PE);

	        /* Disable the UART Error Interrupt: (Frame error, noise error, overrun error) */
	        __HAL_UART_DISABLE_IT(huart, UART_IT_ERR);

	        huart->State = HAL_UART_STATE_READY;
	      }

	      //HAL_UART_RxCpltCallback(huart);

	      return HAL_OK;
	    }

	    return HAL_OK;
	  //}
	  //else
	  //{
	    //return HAL_BUSY;
	  //}
}
void syncwrite(uint16_t *pos,uint16_t *vel)
{
	int i;
	            dxl_set_txpacket_id(BROADCAST_ID);
				dxl_set_txpacket_instruction(INST_SYNC_WRITE);
				dxl_set_txpacket_parameter(0,30);
				dxl_set_txpacket_parameter(1,4);
				for( i=0; i<NUM_ACTUATOR; i++ )
				{
					dxl_set_txpacket_parameter(2+5*i, i+1);
					dxl_set_txpacket_parameter(2+5*i+1,*pos&0xff);
					dxl_set_txpacket_parameter(2+5*i+2,(*pos>>8)&0xff);
					dxl_set_txpacket_parameter(2+5*i+3,*vel&0xff);
					dxl_set_txpacket_parameter(2+5*i+4,(*vel>>8)&0xff);
					vel++,pos++;
				}
				dxl_set_txpacket_length((4+1)*NUM_ACTUATOR+4);
				dxl_txrx_packet();

}
void ik(double *ptr,double x,double y,double z,double phi,double sig,double dip)
{
	double l1=90;     // previous 75
	double l2=56.5;
	double l3=42.3;
	double pi=3.1416;
	z=(290-dip)-37.2-z;

	double t1=atan2(y,z);
	double t5=-t1;

	z=z+(sqrt((z*z)+(y*y))-(z)-64);

	double x1 = x-l3*cos((phi*pi)/180);
	double z1 = z-l3*sin((phi*pi)/180);

	double z2 =  -(z1)/sqrt((x1*x1)+(z1*z1));
	double x2 =  -(x1)/sqrt((x1*x1)+(z1*z1));


	double t2 = (atan2(z2,x2)+ sig*acos(-((x1*x1)+(z1*z1)+(l1*l1)-(l2*l2))/((2*l1)*(sqrt((x1*x1)+(z1*z1))))));

	double z3 = (z1-l1*sin(t2))/l2;
	double x3 = (x1-l1*cos(t2))/l2;

	double  t3 = (atan2(z3,x3)-t2);

	double t4 =((phi*(pi/180))-(t2+t3));
	double a1=t2*(180/pi);
	double a2=t3*(180/pi);
	double a3=t4*(180/pi);
	*ptr=t1;
	*(++ptr)=t2;
	*(++ptr)=t3;
	*(++ptr)=t4;
	*(++ptr)=t5;

}
void getelement(double *ptr,double *element,int no)
{
 	*element=*(ptr+no);
}
void setelement(double *ptr,double element,int no)
{
	*(ptr+no)=element;
}
void motor(uint16_t *pos,uint16_t *vel,double *tl,double *tr)
{
	float diff=1.5708,pi=3.1416;
    int i;
    double temp,temp1;
    /*
     *  TL(1,2)=TR(1,2)-1.5708
     */
    getelement(tl,&temp,1);
	setelement(tl,temp-diff,1);
	/*
	 * TR(1,2)=TR(1,2)-1.5708;
	 */
	getelement(tr,&temp,1);
	setelement(tr,temp-diff,1);
	/*
		 * temp=Tl(1,2);
		 * Tl(1,2)=Tl(1,4);
		 * Tl(1,4)=temp;
		 */
	getelement(tl,&temp,1);
	getelement(tl,&temp1,3);
	setelement(tl,temp1,1);
	setelement(tl,temp,3);
	/*
	 * temp=TR(1,2);
	 * TR(1,2)=TR(1,4);
	 * TR(1,4)=temp;
	 */
	getelement(tr,&temp,1);
	getelement(tr,&temp1,3);
	setelement(tr,temp1,1);
	setelement(tr,temp,3);
	/*
	 * TR(1,1)=3*TR(1,1);
	 * TR(1,5)=3*TR(1,5);
	 */
	getelement(tr,&temp,0);
	setelement(tr,5*temp,0);
	setelement(tr,5*temp,4);
	/*
	 * TL(1,1)=3*TL(1,1);
	 * TL(1,5)=3*TL(1,5);
	 */
	getelement(tl,&temp,0);
	setelement(tl,5*temp,0);
	setelement(tl,5*temp,4);
	/*
	 * TL=TL.*direction_left;
     * TR=TR.*direction_right;
	 * pos_vec=(T+pi)*(180.0/pi)*(4096.0/360.0);
	 * pos_vec=int16(pos_vec);
	 * v=150;
	 * vel_vec=[v,v,v,v,v,v,v,v,v,v];
	 */
	for(i=0;i<10;i++)
	{
		if(i%2==0)
		{
		getelement(tl,&temp,i/2);
		//setelement(tl,direction_left[i/2]*temp,i/2);
		*pos=(uint16_t)((direction_left[i/2]*temp+pi)*converttopos);
		}
		else
		{
		getelement(tr,&temp,i/2);
		//setelement(tr,direction_right[i/2]*temp,i/2);
		*pos=(uint16_t)((direction_right[i/2]*temp+pi)*converttopos);
		}
		if(i==6)
			*pos=*pos+80;
		if(i==7)
			*pos=*pos-80;
		*vel=512;
		vel++;
		pos++;

	}



}
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
